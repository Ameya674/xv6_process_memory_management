# CSE 536: (Assignment 2) Process Memory Management - On Demand Paging & Copy-On-Write

Please refer to the assignment handout posted on Canvas for a list of tasks.

## Acknowledgement

We remain thankful to the xv6 team at MIT for their open-source codebase. 
