/* This file contains code for a generic page fault handler for processes. */
#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"
#include "elf.h"

#include "sleeplock.h"
#include "fs.h"
#include "buf.h"

int loadseg(pagetable_t pagetable, uint64 va, struct inode *ip, uint offset, uint sz);
int flags2perm(int flags);

/* CSE 536: (2.4) read current time. */
uint64 read_current_timestamp() {
  uint64 curticks = 0;
  acquire(&tickslock);
  curticks = ticks;
  wakeup(&ticks);
  release(&tickslock);
  return curticks;
}

bool psa_tracker[PSASIZE];

/* All blocks are free during initialization. */
void init_psa_regions(void)
{
    for (int i = 0; i < PSASIZE; i++) 
        psa_tracker[i] = false;
}

int find_free_blocks() {
    for (int i = 0; i < PSASIZE - 4; i++) {
        if (!psa_tracker[i] && !psa_tracker[i+1] && !psa_tracker[i+2] && !psa_tracker[i+3]) {
            return i;
        }
    }
    return -1; 
}

int victim_pg_fifo(struct proc *p) {
    int last_used_index = -1;
    uint64 last_load_time = 0xFFFFFFFFFFFFFFFF;

    for (int i = 0; i < MAXHEAP; i++) {
        if( p->heap_tracker[i].addr != 0xFFFFFFFFFFFFFFFF && p->heap_tracker[i].loaded == 1 && p->heap_tracker[i].startblock == -1)
        {
        	if(last_load_time > p->heap_tracker[i].last_load_time)
        	{
        		last_used_index = i;
            		last_load_time = p->heap_tracker[i].last_load_time;	
            	}
        }
    }
    return last_used_index; 
}

/* Evict heap page to disk when resident pages exceed limit */
// (2.4.3)
void evict_page_to_disk(struct proc* p) {
    /* Find free block */
    int blockno = find_free_blocks();
    if(blockno == -1) {
        panic("No free consecutive PSA blocks available!");
    }
    psa_tracker[blockno] = true;
    psa_tracker[blockno + 1] = true;
    psa_tracker[blockno + 2] = true;
    psa_tracker[blockno + 3] = true;
 
    /* Find victim page using FIFO. */
    int victim_pg_index = victim_pg_fifo(p);
    uint64 victim_pg_addr = p->heap_tracker[victim_pg_index].addr;
    /* Print statement. */
    // (2.4.5)
    print_evict_page(victim_pg_addr, blockno);
    /* Read memory from the user to kernel memory first. */
    void *cpblk = kalloc();
    copyin(p->pagetable, cpblk, victim_pg_addr, PGSIZE);
    
    /* Write to the disk blocks. Below is a template as to how this works. There is
     * definitely a better way but this works for now. :p */
    for (int i = 0; i < 4; i++) 
    {
	    struct buf* b;
	    b = bread(1, PSASTART+(blockno+i));
	    // Copy page contents to b.data using memmove.
	    memmove(b->data, cpblk + (i*BSIZE), BSIZE);
	    bwrite(b);
	    brelse(b);
    }
    kfree(cpblk);
    
    /* Unmap swapped out page */
    uvmunmap(p->pagetable, victim_pg_addr, 1, 1);
    
    /* Update the resident heap tracker. */
    p->heap_tracker[victim_pg_index].startblock = blockno;
    p->heap_tracker[victim_pg_index].loaded = 0;
}

/* Retrieve faulted page from disk. */
// (2.4.4)
void retrieve_page_from_disk(struct proc* p, int heap_index, uint64 uvaddr) {
    
    // Find where the page is located in disk
    int startblock = p->heap_tracker[heap_index].startblock;
    if (heap_index == -1) {
        panic("Invalid uvaddr provided for retrieve_page_from_disk!");
        return;
    }

    // Check if the page is on the disk.
    if (p->heap_tracker[heap_index].startblock == -1) {
        panic("The page is not swapped to disk!");
        return;
    }
    
    // Print value of uvaddr and startblock
    // (2.4.5)
    print_retrieve_page(uvaddr, startblock);

    // Create a kernel page to read memory temporarily into first.
    void *cpblk = kalloc();
    if (!cpblk) {
        panic("Failed to allocate kernel page!");
        return;
    }
    
    for (int i = 0; i < 4; i++) 
    {
	    struct buf* b;
	    b = bread(1, PSASTART+(startblock+i));
	    memmove(cpblk + (i*BSIZE), b->data, BSIZE);
	    brelse(b);
	    psa_tracker[startblock+i] = false;
    }

    /* Copy from temp kernel page to uvaddr (use copyout) */
    if(copyout(p->pagetable, uvaddr, cpblk, PGSIZE) < 0){
    	panic("Copyout Failed!");
    }
    kfree(cpblk);
    
    p->heap_tracker[heap_index].startblock = -1;
    p->heap_tracker[heap_index].loaded = 1;
}


void page_fault_handler(void) 
{
    /* Current process struct */
    struct proc *p = myproc();

    /* Track whether the heap page should be brought back from disk or not. */
    bool load_from_disk = false;

    /* Find faulting address. */
    // (2.2.2) calculating page fault offset
    uint64 faulting_addr = r_stval();
    uint64 page_offset = faulting_addr & 0xFFF;
    faulting_addr = faulting_addr - page_offset;
    // (2.2.4) print the page fault
    print_page_fault(p->name, faulting_addr);
    pagetable_t pagetable = p->pagetable;
    
    // cow check and call
    if (p->cow_enabled == 1 && r_scause() == 15)
    {
    	copy_on_write();
    	goto out;
    }
    
    //Setting the start index as -1, as we start traversal from 0
    int heap_index = -1;
    //Looping from the start of the heap(0) to the end of the heap(MAXHEAP)
    for(int i = 0; i < MAXHEAP && heap_index == -1; i++)
    	//Checking the the base of the fault address matches the heap's address
        if(faulting_addr == p->heap_tracker[i].addr)
            heap_index = i;
    // if the heap is ondemand and we got a match for heap index
    if (heap_index != -1 && p->ondemand) {
        goto heap_handle;
    }
    
    struct elfhdr elf;
    struct proghdr ph;
    struct inode *ip;
    int i, off;
    
    begin_op();

    if((ip = namei(p->name)) == 0){
      end_op();
    }
    ilock(ip);
    
    if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
        panic("Could not read elf header");

    if(elf.magic != ELF_MAGIC)
        panic("Could not match elf magic");
    // (2.2.3) load faulted page from disk
    for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
        if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
            panic("Could not read ph");
        
        if(ph.type != ELF_PROG_LOAD)
            continue;
        uint64 sz1;
        if(ph.vaddr <= faulting_addr && faulting_addr < ph.vaddr + ph.memsz){
        	if((sz1 = uvmalloc(pagetable, faulting_addr, faulting_addr + 4096, flags2perm(ph.flags))) == 0)
            		panic("Could not allocate page table to process");
		if(loadseg(pagetable, faulting_addr, ip, ph.off, ph.filesz) < 0)
    			panic("Could not load segment");
    		break;
    	}
    }
    iunlockput(ip);
    end_op();
    ip = 0;
    
    /* If it came here, it is a page from the program binary that we must load. */
    // (2.2.4) printing the address of the faulted page
    print_load_seg(faulting_addr, ph.off, ph.memsz);
    
    /* Go to out, since the remainder of this code is for the heap. */
    goto out;

heap_handle:
    /* 2.4: Check if resident pages are more than heap pages. If yes, evict. */
    if (p->resident_heap_pages == MAXRESHEAP) {
        // (2.4.3)
        evict_page_to_disk(p);
        // (2.4.2)
        p->resident_heap_pages--;
    }

    /* 2.3: Map a heap page into the process' address space. (Hint: check growproc) */
    //allocating pagetable for the ondemand heap 
    uvmalloc(pagetable, faulting_addr, faulting_addr + 4096, PTE_W);

    /* 2.4: Update the last load time for the loaded heap page in p->heap_tracker. */
    // (2.4.1)
    p->heap_tracker[heap_index].last_load_time = read_current_timestamp();
    p->heap_tracker[heap_index].loaded = 1;


    /* 2.4: Heap page was swapped to disk previously. We must load it from disk. */
    load_from_disk = (p->heap_tracker[heap_index].startblock != -1);
    if (load_from_disk) {
        retrieve_page_from_disk(p, heap_index, faulting_addr);
    }

    /* Track that another heap page has been brought into memory. */
    // (2.4.2)
    p->resident_heap_pages++;

out:
    /* Flush stale page table entries. This is important to always do. */
    sfence_vma();
    return;
}
